# MRM Care — 20-Screen Framed Screenshot Pack (Original iPhone 17 Pro Max from https://bezel.fit)

- **Device Frame**: Original iPhone 17 Pro Max (`iphone-17-pro-max`) from https://bezel.fit
- **Frame Resolution**: `1472 × 3002` px (Lossless RGBA PNG with transparent exterior corners)
- **Screen Viewport**: `1320 × 2868` px (3x Retina of `440 × 956` pt) placed at `x: 76, y: 67`
- **Included Screens**: All 20 MRM Care screens (#01 to #20) in Silver Titanium, plus Cosmic Orange and Deep Blue editions of #06 Home Screen.
